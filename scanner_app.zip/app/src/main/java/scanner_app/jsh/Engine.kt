package scanner_app.jsh

import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL

class Engine(private val serverUrl: String) {

    fun sendMessage(text: String): String {
        return try {
            val url = URL("$serverUrl/api/chat")
            val conn = url.openConnection() as HttpURLConnection
            conn.requestMethod = "POST"
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json")
            conn.connectTimeout = 30000
            conn.readTimeout = 60000

            val jsonInput = JSONObject()
            jsonInput.put("text", text)
            val outputStream = OutputStreamWriter(conn.outputStream)
            outputStream.write(jsonInput.toString())
            outputStream.flush()
            outputStream.close()

            val responseCode = conn.responseCode
            val inputStream = if (responseCode in 200..299) conn.inputStream else conn.errorStream
            val reader = BufferedReader(InputStreamReader(inputStream))
            val response = StringBuilder()
            var line = reader.readLine()
            while (line != null) {
                response.append(line)
                line = reader.readLine()
            }
            reader.close()

            val jsonResponse = JSONObject(response.toString())
            val reply = jsonResponse.optString("reply", "")
            
            val irData = jsonResponse.optJSONObject("ir_data")
            if (irData != null) {
                val protocol = irData.optString("protocol", "")
                val code = irData.optString("code", "")
                return "$reply\n[ИК-ДАННЫЕ] Протокол: $protocol, Код: $code\n(Скопируй код и отправь через ИК)"
            }

            val data = jsonResponse.opt("data")
            if (data != null) {
                return "$reply\n\nДанные:\n${formatData(data)}"
            }

            reply
        } catch (e: Exception) {
            "Ошибка сети: ${e.message}\n(Сервер просыпается? Попробуй еще раз)"
        }
    }

    private fun formatData(data: Any): String {
        val sb = StringBuilder()
        if (data is JSONArray) {
            for (i in 0 until data.length()) {
                val item = data.optJSONObject(i)
                if (item != null) {
                    val ip = item.optString("ip", "")
                    val port = item.optString("port", "")
                    val status = item.optString("status", "")
                    val path = item.optString("path", "")
                    val info = item.optString("info", "")
                    
                    if (ip.isNotEmpty()) sb.append("• IP: $ip:$port ($status)\n")
                    if (path.isNotEmpty()) sb.append("• Путь: $path\n  Инфо: $info\n")
                }
            }
        } else if (data is JSONObject) {
            sb.append(data.toString(2))
        }
        return sb.toString()
    }
}