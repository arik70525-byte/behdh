package scanner_app.jsh

import android.app.Activity
import android.hardware.ConsumerIrManager
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import java.util.Locale

class MainActivity : Activity() {

    private lateinit var chatLayout: LinearLayout
    private lateinit var inputText: EditText
    private lateinit var sendBtn: Button
    private lateinit var engine: Engine
    private lateinit var scrollView: ScrollView
    private var irManager: ConsumerIrManager? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // ТВОЙ URL С RENDER
        val SERVER_URL = "https://render-ih42.onrender.com" 
        
        engine = Engine(SERVER_URL)
        irManager = getSystemService(ConsumerIrManager::class.java)

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(0xFF121212.toInt())

        val header = TextView(this)
        header.text = "Leviathan Core"
        header.textSize = 18f
        header.setTextColor(0xFF4CAF50.toInt())
        header.setPadding(16, 16, 16, 16)
        header.gravity = Gravity.CENTER
        root.addView(header)

        scrollView = ScrollView(this)
        chatLayout = LinearLayout(this)
        chatLayout.orientation = LinearLayout.VERTICAL
        chatLayout.setPadding(16, 16, 16, 16)
        scrollView.addView(chatLayout)
        root.addView(scrollView, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))

        val bottomBar = LinearLayout(this)
        bottomBar.orientation = LinearLayout.HORIZONTAL
        bottomBar.setBackgroundColor(0xFF1E1E1E.toInt())
        bottomBar.setPadding(8, 8, 8, 8)

        inputText = EditText(this)
        inputText.hint = "Например: номер 79991112233 или сайт example.com"
        inputText.setTextColor(0xFFFFFFFF.toInt())
        inputText.setHintTextColor(0xFF888888.toInt())
        bottomBar.addView(inputText, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))

        sendBtn = Button(this)
        sendBtn.text = "Send"
        bottomBar.addView(sendBtn)

        root.addView(bottomBar)
        setContentView(root)

        sendBtn.setOnClickListener {
            val text = inputText.text.toString().trim()
            if (text.isNotEmpty()) {
                addMessage("Ты: $text", false)
                inputText.setText("")
                sendBtn.isEnabled = false
                
                Thread {
                    val response = engine.sendMessage(text)
                    runOnUiThread {
                        addMessage("Мозг: $response", true)
                        sendBtn.isEnabled = true
                    }
                }.start()
            }
        }

        addMessage("Мозг: Привет! Я готов.\nКоманды:\n- камеры\n- сайт example.com\n- номер 79991112233\n- ИК samsung power", true)
    }

    private fun addMessage(msg: String, isBot: Boolean) {
        val tv = TextView(this)
        tv.text = msg
        tv.setPadding(24, 16, 24, 16)
        tv.textSize = 14f
        
        val params = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        params.setMargins(0, 8, 0, 8)
        
        if (isBot) {
            tv.setBackgroundColor(0xFF2C2C2C.toInt())
            tv.setTextColor(0xFFE0E0E0.toInt())
            params.gravity = Gravity.START
        } else {
            tv.setBackgroundColor(0xFF1B5E20.toInt())
            tv.setTextColor(0xFFFFFFFF.toInt())
            params.gravity = Gravity.END
        }
        tv.layoutParams = params
        chatLayout.addView(tv)
        
        scrollView.post { scrollView.fullScroll(View.FOCUS_DOWN) }
    }
}